look at the top left for how the control work it not a bug but a feature 
this game is about clean up with how the ship work by each key going of North Easth South West and it up you the player to clean up the sea.
Warning the Clean up Crew has not be add to the game as they are currenty on break
Thank you for play boat Clean up this game was made during Game Jam 11/12/2021 in 10 hour
Create by Liam Thomas 